EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'scncsoft@gmail.com'
EMAIL_HOST_PASSWORD = 'passwod'
EMAIL_PORT = 587